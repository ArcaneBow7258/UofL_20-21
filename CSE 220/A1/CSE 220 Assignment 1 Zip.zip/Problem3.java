package assignment1;


public class Problem3 {
	public static void main(String[] args) {
		int hours = 5;
		int minutes = 12;
		int seconds = 30;
		int totalTime = 0;

		
		totalTime = (hours * 60 * 60) + (minutes * 60) + seconds;
		System.out.println("The equivalent time of " + hours + " hours, " + minutes+ " minutes, and " + seconds+ " seconds is: " + totalTime + " seconds");
		
	}
}
