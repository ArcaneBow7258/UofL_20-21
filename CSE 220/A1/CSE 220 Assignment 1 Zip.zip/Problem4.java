package assignment1;
import java.util.Scanner;
public class Problem4 {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a square side length");
		double side = scan.nextDouble();
		
		System.out.println("The perimeter of the square is: " + (side * 4));
		System.out.println("The area of the square is: " + (side*side));
		
		scan.close();
	}
}
