package assignment1;
import java.util.Scanner;
public class Problem5 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter your numerator");
		int num = scan.nextInt();
		System.out.println("Enter your denominator");
		int den = scan.nextInt();
		
		System.out.println("The decimal equivalent to your fraction is: " + ((double)num / den));
		scan.close();
	}
}
