package assignment1;

public class Problem2 {
	public static void main(String[] args) {
		// I do not have a middle name
		System.out.println(" AAAAAAAAA      TTTTTTTTTTTTTT     ");
		System.out.println("AAAAAAAAAAA           TT");
		System.out.println("AA       AA           TT   ");
		System.out.println("AA       AA           TT  ");
		System.out.println("AAAAAAAAAAA           TT    ");
		System.out.println("AAAAAAAAAAA           TT  ");
		System.out.println("AA       AA           TT  ");
		System.out.println("AA       AA           TT  ");
		System.out.println("AA       AA           TT  ");
	}
}
