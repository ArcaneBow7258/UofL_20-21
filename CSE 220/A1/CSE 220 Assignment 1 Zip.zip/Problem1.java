package assignment1;

public class Problem1 {
	public static void main(String[] args)
	{
		System.out.println("Name: Alvin Tran");
		System.out.println("DOB: 01/28/2002");
		System.out.println("Hobbies: Games (Board and Video), Reading, Learning Hobbies, Working out?");
		System.out.println("Favorite Book: Mistborn or The Wandering Inn ");
		System.out.println("Favorite Movie: Don't watch many. Possibly Coco?"); 
	}
}
